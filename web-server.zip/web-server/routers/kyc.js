const router = require("express").Router();
const auth = require("./auth");
const multer = require("multer");
const path = require("path");
const mysql = require("mysql");
const crypto = require("crypto");
const AccountVerifiedEmail = require("./Emails/AccountVerifiedEmail");
const KycRejectedEmail = require("./Emails/KycRejectedEmail");
const KYCUploadedEmai = require("./Emails/KYCUploadedEmai");
const adminAuth = require("./adminAuth");
const db = mysql.createConnection({
  host: "localhost",
  user: process.env.database_user,
  database: process.env.database_name,
  password: process.env.database_password,
});

console.log(process.env.database_name);

db.connect((error) => {
  if (error) {
    console.log(error);
  }
  console.log("SQL Connected");
});

const storage = multer.diskStorage({
  destination: "./web-server/web-folder/public/webStorage/kyc",
  filename: function (req, file, cb) {
    cb(null, "kyc" + "-" + Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({
  // limits: 300000,
  storage: storage,
});

//
// @KYC
router.get("/pending-verification", auth, async (req, res) => {
  try {
    res.render("pendingVerification");
  } catch (error) {
    console.log(error);
    res.send(error);
    // res.redirect("/error-page?error=" + error.message);
  }
});

// @KYC
router.get("/view-kyc-data/:_id", adminAuth, async (req, res) => {
  try {
    async function SQLQUERY(val) {
      return new Promise((resolve, reject) => {
        let sql = val;
        db.query(sql, (error, result) => {
          if (error) {
            console.log(error);
            return res.redirect("/login");
          }
          resolve(result);
        });
      });
    }

    let kycData = await SQLQUERY(
      `SELECT * FROM kyc WHERE owner='${req.params._id}' ORDER BY id DESC`
    );

    if (kycData.length < 1)
      return res.send(`<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>No KYC Upload</title>
    </head>
    <body style="font-family: Arial, sans-serif; margin: 0; background-color: #f5f5f5; display: flex; justify-content: center; align-items: center; min-height: 100vh;">
    
    <div style="background-color: white; padding: 20px; border-radius: 10px; box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1); text-align: center; max-width: 400px; width: 100%;">
        <p style="font-size: 24px; margin-bottom: 20px;">No KYC Upload</p>
        <button style="padding: 10px 20px; font-size: 18px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s ease;" onclick="goBack()">Go Back</button>
    </div>
    
    <script>
        function goBack() {
            window.history.back();
        }
    </script>
    
    </body>
    </html>
    `);

    kycData = kycData[0];

    let user = await SQLQUERY(
      `SELECT * FROM users WHERE _id='${req.params._id}'`
    );

    user = user[0];
    res.render("admin/admin-kyc-list", { kycData, user });
  } catch (error) {
    console.log(error);
    res.send(error);
    // res.redirect("/error-page?error=" + error.message);
  }
});

// @KYC
router.get("/kyc", auth, async (req, res) => {
  try {
    async function SQLQUERY(val) {
      return new Promise((resolve, reject) => {
        let sql = val;
        db.query(sql, (error, result) => {
          if (error) {
            console.log(error);
            return res.redirect("/login");
          }
          resolve(result);
        });
      });
    }

    let user = await SQLQUERY(
      `SELECT * FROM users WHERE _id='${req.user._id}'`
    );
    user = user[0];
    res.render("dashboard/kyc", { user });
  } catch (error) {
    console.log(error);
    res.send(error);
    // res.redirect("/error-page?error=" + error.message);
  }
});

// UPDATE Image and Staus to  Await approval
router.post("/kyc-upload", upload.single("upload"), auth, async (req, res) => {
  try {
    async function SQLQUERY(val) {
      return new Promise((resolve, reject) => {
        let sql = val;
        db.query(sql, (error, result) => {
          if (error) {
            console.log(error);
            return res.redirect("/login");
          }
          resolve(result);
        });
      });
    }

    let user = await SQLQUERY(
      `SELECT * FROM users WHERE _id='${req.user._id}'`
    );
    user = user[0];
    
    let data = {
      _id: crypto.randomBytes(12).toString("hex"),
      fullName: req.body.fullName,
      address: req.body.address,
      idType: req.body.idType,
      idNumber: req.body.idNumber,
      image: req.file.filename,
      owner: req.body.user_id,
      status: "pending",
    };

    let sql = "INSERT INTO kyc SET ?";

    db.query(sql, data, (error) => {
      if (error) {
        return console.log(error);
      }
      KYCUploadedEmai(user)
      console.log("KYC UPLoaded");
    });

    res.redirect(`/home`);
  } catch (error) {
    console.log(error);
    res.send("An error occured please try again later");
  }
});

// Update KYC STATUS
router.get("/update-kyc-status", adminAuth, async (req, res) => {
  try {
    async function SQLQUERY(val) {
      return new Promise((resolve, reject) => {
        let sql = val;
        db.query(sql, (error, result) => {
          if (error) {
            console.log(error);
            return res.redirect("/login");
          }
          resolve(result);
        });
      });
    }

    let kycData = await SQLQUERY(
      `SELECT * FROM kyc WHERE _id='${req.query.kyc_id}'`
    );
    kycData = kycData[0];

    let user = await SQLQUERY(
      `SELECT * FROM users WHERE _id='${kycData.owner}'`
    );

    user = user[0];


    if (req.query.status === "approved") {
      let sql = `UPDATE kyc SET status='${req.query.status}' WHERE _id='${req.query.kyc_id}'`;
      db.query(sql, (error) => {
        if (error) {
          return console.log(error);
        }
      });

      AccountVerifiedEmail(user);
      res.redirect(`/view-kyc-data/${kycData.owner}`);
      return;
    }

    if (req.query.status === "rejected") {
      let sql = `DELETE FROM kyc WHERE _id='${req.query.kyc_id}'`;

      db.query(sql, (error) => {
        if (error) {
          return console.log(error);
        }
        console.log("Deleted everything");
      });

      KycRejectedEmail(user)

      res.redirect("/users");
    }
  } catch (error) {
    console.log(error);
  }
});

module.exports = router;
