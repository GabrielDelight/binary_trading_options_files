const nodemailer = require("nodemailer");
const fs = require("fs");
// Sending emails

function WithdrawlEmail(user) {
  // setup email data with unicode symbols
  let transporter = nodemailer.createTransport({
    host: "mail.binarytradingoptions.org",
    name: "binarytradingoptions.org",
    pool: true,
    port: 587, //<----change
    secure: false,

    auth: {
      user: "support@binarytradingoptions.org", // generated ethereal user
      pass: "binarytradingoptions", // generated ethereal password
    },
    tls: {
      rejectUnauthorized: false,
    },
  });


  let mailOptions = {
    from: '"Binary Trading Options" <support@binarytradingoptions.org>', // sender address
    to: user.email, // list of receivers
    subject: `"Withdrawal Approval: Your Request for $${user.amount} has been Approved"`, // Subject line
    // text: "Hello world?", // plain text body
    html: `
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: Arial, sans-serif; background-color: #f5f5f5; margin: 0;">

<div style="background-color: white; padding: 20px; border-radius: 10px; box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1); text-align: left; max-width: 600px; margin: 20px auto;">
    <h2>Withdrawal Approved</h2>
    <p style="font-size: 18px; margin-bottom: 20px;">Hello ${user.firstname},</p>
    <p>We are thrilled to inform you that your withdrawal request of $${user.amount} has been approved and processed successfully. Your funds will be on their way to you shortly.</p>
    <p>We greatly appreciate your trust in our platform. Your satisfaction is our utmost priority.</p>
    <p>If you have any questions or need further assistance, feel free to reach out to our support team.</p>
    <p>Thank you for being a valued member of our community!</p>
</div>

</body>
</html>

    
    
    `, // html body
  };

  // send mail with defined transport object
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return console.log(error);
    }
    console.log("Message sent: %s", info.messageId);
    console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
    console.log("Email has been sent");

  });

  return transporter;
}

module.exports = WithdrawlEmail;
