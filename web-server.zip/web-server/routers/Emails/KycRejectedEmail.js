const nodemailer = require("nodemailer");
const fs = require("fs");
// Sending emails

function KycRejectedEmail(user) {
  // setup email data with unicode symbols
  let transporter = nodemailer.createTransport({
    host: "mail.binarytradingoptions.org",
    name: "binarytradingoptions.org",
    pool: true,
    port: 587, //<----change
    secure: false,

    auth: {
      user: "support@binarytradingoptions.org", // generated ethereal user
      pass: "binarytradingoptions", // generated ethereal password
    },
    tls: {
      rejectUnauthorized: false,
    },
  });


  let mailOptions = {
    from: '"Binary Trading Options" <support@binarytradingoptions.org>', // sender address
    to: user.email, // list of receivers
    subject: `KYC Verification Status: Rejected`, // Subject line
    // text: "Hello world?", // plain text body
    html: `
    <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; background-color: #f5f5f5; margin: 0;">

        <div style="background-color: white; padding: 20px; border-radius: 10px; box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1); text-align: left; max-width: 600px; margin: 20px auto;">
            <h2>KYC Verification Rejected</h2>
            <p style="font-size: 18px; margin-bottom: 20px;">Dear ${user.firstname},</p>
            <p>We regret to inform you that your KYC verification has been rejected. Our team has reviewed the information provided and found that it does not meet our verification criteria.</p>
            <p>If you believe this decision was made in error, please contact our support team for further assistance.</p>
            <p>Thank you for your understanding.</p>
        </div>

        </body>
        </html>
    
    `, // html body
  };

  // send mail with defined transport object
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return console.log(error);
    }
    console.log("Message sent: %s", info.messageId);
    console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
    console.log("Email has been sent");

  });

  return transporter;
}

module.exports = KycRejectedEmail;
