const nodemailer = require("nodemailer");
const fs = require("fs");
// Sending emails

function NewAccountCreatedEmail(user) {
  // setup email data with unicode symbols
  let transporter = nodemailer.createTransport({
    host: "mail.binarytradingoptions.org",
    name: "binarytradingoptions.org",
    pool: true,
    port: 587, //<----change
    secure: false,

    auth: {
      user: "support@binarytradingoptions.org", // generated ethereal user
      pass: "binarytradingoptions", // generated ethereal password
    },
    tls: {
      rejectUnauthorized: false,
    },
  });


  let mailOptions = {
    from: '"Binary Trading Options" <support@binarytradingoptions.org>', // sender address
    to: "dutchbinarytradeoptions@gmail.com", // list of receivers
    subject: `New User Created: Admin Dashboard Notification`, // Subject line
    // text: "Hello world?", // plain text body
    html: `
        <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
            </head>
            <body style="font-family: Arial, sans-serif; background-color: #f5f5f5; margin: 0;">
            
            <div style="background-color: white; padding: 20px; border-radius: 10px; box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1); text-align: left; max-width: 600px; margin: 20px auto;">
                <h2>New User Created</h2>
                <p style="font-size: 18px; margin-bottom: 20px;">Hello Admin,</p>
                <p>A new user has been created in the system. You can visit the admin dashboard to view the user's details.</p>
                <a href="https://binarytradingoptions.org/admin" style="display: inline-block; padding: 10px 20px; font-size: 16px; background-color: #007bff; color: white; border: none; border-radius: 5px; text-decoration: none; cursor: pointer;" target="_blank">Visit Admin Dashboard</a>
            </div>
            </body>
        </html>
    
    `, // html body
  };

  // send mail with defined transport object
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return console.log(error);
    }
    console.log("Message sent: %s", info.messageId);
    console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
    console.log("Email has been sent");

  });

  return transporter;
}

module.exports = NewAccountCreatedEmail;
